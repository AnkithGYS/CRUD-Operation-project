function fillForm(id, name, email, dob) {
  document.getElementById('id').value = id;
  document.getElementById('name').value = name;
  document.getElementById('email').value = email;
  document.getElementById('dob').value = dob;
}
