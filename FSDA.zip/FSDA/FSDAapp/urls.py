from django.urls import path
from . import views

urlpatterns = [
    path('', views.CRUD, name='CRUD'),
    path('delete/<int:id>/', views.delete_user, name='delete_user'),
]
