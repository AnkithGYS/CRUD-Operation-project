from django.shortcuts import render, redirect, get_object_or_404
from .models import Registration

def CRUD(request):
    registrations = Registration.objects.all().order_by('-id')

    if request.method == 'POST':
        user_id = request.POST.get('id')
        name = request.POST.get('name')
        email = request.POST.get('email')
        dob = request.POST.get('date_of_birth')

        if user_id: 
            user = get_object_or_404(Registration, id=user_id)
            user.name = name
            user.email = email
            user.date_of_birth = dob
            user.save()
        else: 
            Registration.objects.create(
                name=name,
                email=email,
                date_of_birth=dob
            )

        return redirect('CRUD')

    return render(request, 'index.html', {'registrations': registrations})

def delete_user(request, id):
    user = get_object_or_404(Registration, id=id)
    user.delete()
    return redirect('CRUD')
